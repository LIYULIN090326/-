#include "ls1x.h"
#include "Config.h"
#include "oled.h"
#include "ls1x_spi.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ls1c102_adc.h"

uint8_t MQ2_Read(void) {
    // 假设MQ-2传感器输出信号接在GPIO_PIN_25上
    return gpio_get_pin(GPIO_PIN_25); // 读取MQ-2传感器的输出信号
}

int main(int arg, char *args[])
{
    int smokeDetected = 0; // 表示烟雾是否检测到的变量
    int adcValue = 0; // 存储ADC读数的变量
    int smokePercentage = 0; // 存储烟雾浓度百分比的整数

    AFIO_RemapConfig(AFIOB, GPIO_Pin_4, 0); // 假设这是用于GPIO_PIN_4的配置
    Adc_powerOn(); // 打开ADC电源
    Adc_open(ADC_CHANNEL_I5); // 打开ADC通道I5（假设这是你的设置）

    gpio_write_pin(GPIO_PIN_20, 1); // 先点亮LED灯
    Spi_Init(SPI_DIV_2); // 初始化SPI
    OLED_Init(); // 初始化OLED
    OLED_Clear(); // 清空OLED屏幕
    gpio_write_pin(GPIO_PIN_20, 0); // 关闭LED灯

    delay_ms(1000); // 延时1秒

    while(1)
    {
        // 读取ADC数值
        adcValue = Adc_Measure(ADC_CHANNEL_I5);

        // 读取MQ-2传感器数值（假设有MQ2_Read函数）
        smokeDetected = MQ2_Read(); // 这个函数应该从GPIO_PIN_25读取

        // 将ADC数值映射为百分比浓度（假设ADC范围是0到4095）
        //smokePercentage = (adcValue * 100) / 4095;
        smokePercentage = ((adcValue-1500) * 100) / (3000-1500);

        if(smokePercentage < 0){
            smokePercentage = 0;
        }
       
        printf("smokePercentage: %d°C\n", smokePercentage);

        // 在OLED上显示烟雾浓度百分比
        OLED_Clear();
        
        OLED_ShowString(0, 0, "Smoke:");
        OLED_ShowNum(0, 16, smokePercentage, 2, 16);   // 显示湿度，假设湿度是两位数字
        OLED_ShowChar(16, 16, '%', 16);          // 显示百分号

        if(smokePercentage>=15){
            gpio_write_pin(GPIO_PIN_14, 1); // 打开LED灯
        }else{
            gpio_write_pin(GPIO_PIN_14, 0); // 关闭LED灯
        }

        if (smokeDetected == 0) {
            OLED_ShowString(0, 32, "Smoke Detected");
        } else {
            OLED_ShowString(0, 32, "No Smoke");
        }

        delay_ms(1000); // 延时1秒后更新显示
    }

    return 0;
}
