#include "ls1x.h"
#include "Config.h"
#include "oled.h"
#include "ls1x_spi.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ls1c102_adc.h"



int main(int arg, char *args[])
{
    int waterLevel = 0; // 存储水位传感器读数的变量
    int adcValue = 0; // 存储ADC读数的变量
    int waterPercentage = 0; // 存储水位百分比的整数

    AFIO_RemapConfig(AFIOB, GPIO_Pin_4, 0); // 假设这是用于GPIO_PIN_4的配置
    Adc_powerOn(); // 打开ADC电源
    Adc_open(ADC_CHANNEL_I5); // 打开ADC通道I5（假设这是你的设置）

    gpio_write_pin(GPIO_PIN_20, 1); // 先点亮LED灯
    Spi_Init(SPI_DIV_2); // 初始化SPI
    OLED_Init(); // 初始化OLED
    OLED_Clear(); // 清空OLED屏幕
    gpio_write_pin(GPIO_PIN_20, 0); // 关闭LED灯

    delay_ms(1000); // 延时1秒

    while(1)
    {
        // 读取ADC数值
        adcValue = Adc_Measure(ADC_CHANNEL_I5);

        

        // 将ADC数值映射为百分比水位（假设ADC范围是0到4095）
        //waterPercentage = (adcValue * 100) / 4095;
        waterPercentage =(adcValue * 100) / 2252;
        //if(waterPercentage < 0){
        //    waterPercentage = 0;
        //}

        printf("Water Percentage: %d%%\n", waterPercentage);

        // 在OLED上显示水位百分比
        OLED_Clear();
        
        OLED_ShowString(0, 0, "Water:");
        OLED_ShowNum(0, 16, waterPercentage, 2, 16);   // 显示水位百分比，假设是两位数字
        OLED_ShowChar(16, 16, '%', 16);          // 显示百分号

        if(waterPercentage >= 20){
            gpio_write_pin(GPIO_PIN_30, 1); // 打开LED灯
            OLED_ShowString(0, 32, "Water Detected");
        } else {
            gpio_write_pin(GPIO_PIN_30, 0); // 关闭LED灯
            OLED_ShowString(0, 32, "No Water");
        }

        //if (waterLevel == 0) {
        //    OLED_ShowString(0, 32, "Water Detected");
        //} else {
        //    OLED_ShowString(0, 32, "No Water");
        //}

        delay_ms(1000); // 延时1秒后更新显示
    }

    return 0;
}
