#include "ls1x.h"
#include "Config.h"
#include "oled.h"
#include "ls1x_spi.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"



void DHT11_RST(void) {
    gpio_write_pin(GPIO_PIN_23, 0);
    delay_ms(20);
    gpio_write_pin(GPIO_PIN_23, 1);
    delay_us(13);
    
}

uint8_t DHT11_Check(void) {
    uint8_t response = 0;
    delay_us(40);
    if (gpio_get_pin(GPIO_PIN_23) == 0) {
        delay_us(60);
        if (gpio_get_pin(GPIO_PIN_23) == 1) {
            response = 1;
        }
    }
    while (gpio_get_pin(GPIO_PIN_23)); // 等待响应信号结束
    return response;
}



uint8_t DHT11_Init (void){
    //DHT11初始化
    DHT11_RST();								//DHT11端口复位，发出起始信号
    return DHT11_Check(); 						//等待DHT11回应
}

uint8_t DHT11_ReadByte(void) {
    uint8_t i, data = 0;
    for (i = 0; i < 8; i++) {
        while (!gpio_get_pin(GPIO_PIN_23)); // 等待引脚变高
        delay_us(30);
        if (gpio_get_pin(GPIO_PIN_23)) {
            data |= (1 << (7 - i));
        }
        while (gpio_get_pin(GPIO_PIN_23)); // 等待引脚变低
    }
    return data;
}

uint8_t DHT11_ReadData(uint8_t* temperature, uint8_t* humidity) {
    uint8_t buffer[5];
    uint8_t i;
    DHT11_RST();
    if (DHT11_Check()) {
        for (i = 0; i < 5; i++) {
            buffer[i] = DHT11_ReadByte();
        }
        if ((buffer[0] + buffer[1] + buffer[2] + buffer[3]) == buffer[4]) {
            *humidity = buffer[0];
            *temperature = buffer[2];
            return 1;
        }
    }
    return 0;
}

int main(void) {
    uint8_t temperature = 0;
    uint8_t humidity = 0;

    gpio_write_pin(GPIO_PIN_20, 1); // 设置GPIO_PIN_20引脚为高电平（打开LED灯）
    Spi_Init(SPI_DIV_2); // 初始化SPI接口，设置时钟分频器
    OLED_Init(); // 初始化OLED显示模块
    OLED_Clear(); // 清除OLED显示内容
    gpio_write_pin(GPIO_PIN_20, 0); // 设置GPIO_PIN_20引脚为低电平（关闭LED灯）
    
    
    while(1)
    {
        if (DHT11_ReadData(&temperature, &humidity)) {
        
        // LED灯闪烁，用于辅助观察
        gpio_write_pin(GPIO_PIN_20, 1); // 打开LED灯
        delay_ms(1000); // 延时100毫秒
        gpio_write_pin(GPIO_PIN_20, 0); // 关闭LED灯
        delay_ms(300); // 延时300毫秒
        
        // 打印到控制台（可选）
        printf("Temperature: %d°C\n", temperature);
        printf("Humidity: %d%%\n", humidity);

        // 在OLED显示屏上显示温度和湿度数据
        OLED_Clear();
        OLED_ShowString(0, 0, "Temp:");
        OLED_ShowNum(40, 0, temperature, 2, 16); // 显示温度，假设温度是两位数字
        OLED_ShowChar(56, 0, 'C', 16);           // 显示单位 'C'
        
        OLED_ShowString(0, 16, "Humidity:");
        OLED_ShowNum(64, 16, humidity, 2, 16);   // 显示湿度，假设湿度是两位数字
        OLED_ShowChar(80, 16, '%', 16);          // 显示百分号
    } else {
        // 显示错误信息
        OLED_Clear();
        OLED_ShowString(0, 0, "Error reading");
        OLED_ShowString(0, 16, "DHT11 sensor");
    }

    }
    
    return 0; // 返回0，表示程序正常结束
}