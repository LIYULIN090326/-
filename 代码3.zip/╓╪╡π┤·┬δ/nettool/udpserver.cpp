#include "udpserver.h"
#include "quiwidget.h"
 QUdpSocket *udpSocket=nullptr;
udpServer::udpServer(QObject *parent) : QObject(parent)
{
    initUpServer();
}
void udpServer::initUpServer()
{
    udpSocket = new QUdpSocket(this);
    connect(udpSocket, SIGNAL(readyRead()), this, SLOT(readData()));

}
void udpServer::listen(bool flag){
    if(flag)
    {
        #if (QT_VERSION > QT_VERSION_CHECK(5,0,0))
                bool ok = udpSocket->bind(QHostAddress::AnyIPv4, App::UdpListenPort);
        #else
                bool ok = udpSocket->bind(QHostAddress::Any, App::UdpListenPort);
        #endif
                if(ok)
                {
                    qDebug()<<"监听成功";
                }
    }
    else
    {
        udpSocket->abort();
    }

}
void udpServer::readData()
{
    QHostAddress host;
    quint16 port;
    QByteArray data;
    QString buffer;

    while (udpSocket->hasPendingDatagrams()) {
        data.resize(udpSocket->pendingDatagramSize());
        udpSocket->readDatagram(data.data(), data.size(), &host, &port);

        deal_data(data);

        if (App::HexReceiveUdpServer) {
            buffer = QUIHelper::byteArrayToHexStr(data);
        } else if (App::AsciiUdpServer) {
            buffer = QUIHelper::byteArrayToAsciiStr(data);
        } else {
            buffer = QString(data);
        }

        QString ip = host.toString();
        if (ip.isEmpty()) {
            continue;
        }

        QString str = QString("[%1:%2] %3").arg(ip).arg(port).arg(buffer);
        append(1, str);

        if (App::DebugUdpServer) {
            int count = App::Keys.count();
            for (int i = 0; i < count; i++) {
                if (App::Keys.at(i) == buffer) {
                    sendData(ip, port, App::Values.at(i));
                    break;
                }
            }
        }
    }
}
void udpServer::sendData(const QString &ip, int port, const QString &data)
{
    QByteArray buffer;
    if (App::HexSendUdpServer) {
        buffer = QUIHelper::hexStrToByteArray(data);
    } else if (App::AsciiUdpServer) {
        buffer = QUIHelper::asciiStrToByteArray(data);
    } else {
        buffer = data.toLatin1();
    }

    udpSocket->writeDatagram(buffer, QHostAddress(ip), port);

    QString str = QString("[%1:%2] %3").arg(ip).arg(port).arg(data);
    append(0, str);

}
void udpServer::append(int type, const QString &data, bool clear)
{
    emit send_data_to_display(type,data);
}
void udpServer::deal_data(QByteArray data)
{
    if (data.startsWith(QByteArray::fromHex("01 0C")))
    {
        qDebug() << "以 01 0c 开头，进行相应处理";
        emit parse_wavelength_data_sig(data);
    }
    else if (data.startsWith(QByteArray::fromHex("01 10")))
    {
        qDebug() << "以 01 10 开头，进行相应处理";
        emit parse_intensity_data_sig(data);
    }
}
