#include "alarmdialog.h"
#include "ui_alarmdialog.h"


AlarmDialog::AlarmDialog(const QString &title, const QString &body,const QString &message, QWidget *parent):
    QDialog(parent),
    ui(new Ui::AlarmDialog)
{
    ui->setupUi(this);
//    this->setWindowFlags(Qt::FramelessWindowHint);
    this->setWindowTitle("隧道异常告警");
       this->setWindowFlags(windowFlags() &~ Qt::WindowContextHelpButtonHint);
    ui->title->setText(title);
    ui->body->setText(body);
    ui->message->setText(message);
}

AlarmDialog::~AlarmDialog()
{
    emit closeAlarm();
    delete ui;
}

void AlarmDialog::on_close_clicked()
{
    emit closeAlarm();

    this->close();
}
