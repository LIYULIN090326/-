#ifndef MY_WIDGET_FORM_H
#define MY_WIDGET_FORM_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QChartView>
#include <QChart>
#include <QSpacerItem>
#include <QChart>
#include <QLineSeries>
#include <QValueAxis>
#include <QProcess>
#include <QtCharts>
#include <QSplineSeries>
#include <QTimer>
#include <QResizeEvent>
namespace Ui {
class my_widget_form;
}

class my_widget_form : public QWidget
{
    Q_OBJECT

public:
    explicit my_widget_form(QWidget *parent = nullptr);
    ~my_widget_form();
    void resizeEvent(QResizeEvent *event);

    void init_wavelength_widget();

    void init_widget_size();
    void init_intensity_widget();
private slots:
    void on_openudp_clicked();

    void on_readData_clicked();

    void on_connect_clicked();
    void send_command(unsigned char* command, size_t command_len);
    uint16_t crc16(const unsigned char* buf, int len);
public slots:
    void get_data(QString);
    void update_myAlarmWidget(double waterLevel, double humidity, double temperature, double smoke, double strain1,double strain2);
    void update_myWidget(double waterLevel, double humidity, double temperature, double smoke, double strain1,double strain2);
    void parse_wavelength_data(QByteArray data);
    void parse_intensity_data(QByteArray data);

    void update_W_Line();
    void update_I_Line();
    void getMaxMinY(const QList<QPointF> &pointList1,double &maxY,double &minY);
signals:
    void listen_sig(bool);
    //void sendData(const QString &ip, int port, const QString &data);
    void my_widget_form_hide();
    void on_Publisher_Strain(double,double);

private:
    Ui::my_widget_form *ui;
    QTimer *timer;


    QLabel *logo1;
    QLabel *text1;
    QVBoxLayout *layout1;
    QWidget *widget1;

    QLabel *logo2;
    QLabel *text2;
    QVBoxLayout *layout2;
    QWidget *widget2;



    QChart *chart_w;
    QSplineSeries *series_w;
//    QSplineSeries *series_w_2;
    QChartView *chartview_w;
    QList<QPointF> pointList_w;
    QList<QPointF> pointList_w_2;

    QPointF pointw1;
    QPointF pointw2;

    double w_maxy=1536.58;
    double w_miny=1536.10;


    QChart *chart_i;
    QSplineSeries *series_i;
//    QSplineSeries *series_i_2;
    QChartView *chartview_i;
    QList<QPointF> pointList_i;
//    QList<QPointF> pointList_i_2;
    QPointF pointi1;
    QPointF pointi2;

    double i_maxy=0;
    double i_miny=10000;


    double waterLevel=0;
    double humidity=0;
    double temperature=0;
    double smoke=0;
    double strain1=0;
    double strain2=0;


    double waterLevel_alarm=30;//水位
    double humidity_alarm=100;//湿度
    double temperature_alarm=30;//温度
    double smoke_alarm=16;//烟雾
    double strain_alarm=0.1;//应变
    bool dialogshow;

    bool strain1dialogflag=false;
    bool strain2dialogflag=false;


    bool init_widget_size_flag=false;
};

#endif // MY_WIDGET_FORM_H
