#include "my_widget_form.h"
#include "ui_my_widget_form.h"
#include "frmmain.h"
#include "quiwidget.h"
#include "alarmdialog.h"
#include <QDateTime>
#include <QFont>
#include "udpserver.h"
extern  QUdpSocket *udpSocket;
my_widget_form::my_widget_form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::my_widget_form)
{
    ui->setupUi(this);

    widget1=new QWidget(ui->centerwidget);

    logo1=new QLabel(widget1);
    logo1->resize(40,40);
    logo1->setAlignment(Qt::AlignCenter);
    logo1->setPixmap(QPixmap(":/images/green.png"));
    text1=new QLabel(widget1);
    text1->setAlignment(Qt::AlignCenter);
    text1->setText("检测点1");

    layout1=new QVBoxLayout;
    layout1->addWidget(logo1);
    layout1->addWidget(text1);
    widget1->setLayout(layout1);
    widget1->resize(150,120);



    widget2=new QWidget(ui->centerwidget);

    logo2=new QLabel(widget2);
    logo2->resize(40,40);
    logo2->setAlignment(Qt::AlignCenter);
    logo2->setPixmap(QPixmap(":/images/green.png"));
    text2=new QLabel(widget2);
    text2->setAlignment(Qt::AlignCenter);
    text2->setText("检测点2");

    layout2=new QVBoxLayout;
    layout2->addWidget(logo2);
    layout2->addWidget(text2);
    widget2->setLayout(layout2);
    widget2->resize(150,120);



    QFont font;
    font.setFamily("Microsoft YaHei");  // 设置字体类型
    font.setPointSize(15);  // 设置字体大小
    font.setBold(true);  // 设置为加粗
    //font.setItalic(true);  // 设置为倾斜
    text1->setFont(font);
    text2->setFont(font);

    QPalette palette = text1->palette();
    palette.setColor(QPalette::WindowText, Qt::white);
    text1->setPalette(palette);
    text2->setPalette(palette);


    timer=new QTimer;
    connect(timer,&QTimer::timeout,[this](){
       QString date=QDateTime::currentDateTime().toString("yyyy年MM月dd日 HH:mm:ss");
        ui->time->setText(date);
        if(!init_widget_size_flag)
        {
            timer->start(1000);
            init_widget_size_flag=true;
            init_widget_size();
        }
    });
    timer->start(50);
     init_wavelength_widget();

     init_intensity_widget();

//     init_widget_size();
    update_myWidget(0,0,0,0,0,0);
}

my_widget_form::~my_widget_form()
{
    delete ui;
}
void my_widget_form::init_widget_size()
{
    widget1->move(ui->centerwidget->width()*3.5/10,ui->centerwidget->height()*5/11);
    widget2->move(ui->centerwidget->width()*6/10,ui->centerwidget->height()*3/11);
}
void my_widget_form::resizeEvent(QResizeEvent *event)
{
//    int width=ui->centerwidget->width();
//    int height=ui->centerwidget->height();
//    qDebug()<<width<<height;
    widget1->move(ui->centerwidget->width()*3.5/10,ui->centerwidget->height()*5/11);
    widget2->move(ui->centerwidget->width()*6/10,ui->centerwidget->height()*3/11);
}

void my_widget_form::on_openudp_clicked()
{
    emit my_widget_form_hide();
    this->hide();

}
uint16_t my_widget_form::crc16(const unsigned char* buf, int len) {
    uint16_t crc = 0xFFFF;
    for (int pos = 0; pos < len; pos++) {
        crc ^= (uint16_t)buf[pos];
        for (int i = 8; i != 0; i--) {
            if ((crc & 0x0001) != 0) {
                crc >>= 1;
                crc ^= 0xA001;
            }
            else {
                crc >>= 1;
            }
        }
    }
    return crc;
}
void my_widget_form::send_command(unsigned char* command, size_t command_len) {
    uint16_t crc = crc16(command, command_len);
    command[command_len] = crc & 0xFF;
    command[command_len + 1] = (crc >> 8) & 0xFF;
    command_len += 2;

    QString hexString="";
    for (int i = 0; i<command_len; ++i)
    {
        hexString += QString("%1 ").arg(static_cast<unsigned int>(command[i]), 2, 16, QChar('0'));
    }
    qDebug()<<hexString<<"---"<<command_len;

    //emit sendData(App::UdpServerIP,App::UdpServerPort,hexString);

    udpSocket->writeDatagram((const char*)command,command_len, QHostAddress(App::UdpServerIP), App::UdpServerPort);

    //QString str = QString("[%1:%2] %3").arg(App::UdpServerIP).arg(App::UdpServerPort).arg(hexString);
    //append(0, str);
}

void my_widget_form::on_readData_clicked()
{
    if(ui->readData->text()=="启动读取")
    {
        ui->readData->setText("关闭读取");
        unsigned char start_command[6] = { 0x01, 0x0A, 0x55, 0x55 };
        send_command( start_command, 4);
    }
    else
    {
        ui->readData->setText("启动读取");
    }
}

void my_widget_form::on_connect_clicked()
{

    //连接 udp 192.168.0.109
    if (ui->connect->text() == "连接") {
       emit listen_sig(true);
        ui->connect->setText("断开连接");

    } else {
        emit listen_sig(false);
        ui->connect->setText("连接");
    }
}
void my_widget_form::get_data(QString data)
{
    QStringList list=data.split("-");
     waterLevel=list.at(0).toDouble();
     humidity=list.at(1).toDouble();
     temperature=list.at(2).toDouble();
     smoke=list.at(3).toDouble();
     update_myAlarmWidget( waterLevel,  humidity,  temperature,  smoke,  strain1, strain2);
     update_myWidget(waterLevel,  humidity,  temperature,  smoke,  strain1, strain2);
}



void my_widget_form::update_myWidget(double waterLevel, double humidity, double temperature, double smoke, double strain1,double strain2)
{
    ui->progressBar->setRange(0,50);
    ui->progressBar->setValue(temperature);


    ui->progressBar_2->setRange(0,100);
    ui->progressBar_2->setValue(humidity);

    ui->progressBar_3->setRange(0,100);
    ui->progressBar_3->setValue(smoke);

    ui->progressBar_4->setRange(0,100);
    ui->progressBar_4->setValue(waterLevel);

    ui->progressBar_8->setRange(-1000,1000);
    ui->progressBar_8->setValue(strain1*1000);


    ui->progressBar_7->setRange(-1000,1000);
    ui->progressBar_7->setValue(strain2*1000);

    if(temperature!=0)
    {
        if(temperature_alarm<temperature)
        {
           //ui->templogo->setimc


           ui->templogo->setPixmap(QPixmap(":/images/red.png"));
           ui->label_2->setText("<span style='color: red;'>"+QString::number(temperature,'f',1)+"</span>℃");
        }
        else{
            ui->templogo->setPixmap(QPixmap(":/images/green.png"));
            ui->label_2->setText(QString::number(temperature,'f',1)+"℃");
        }

    }
    else
    {
        ui->templogo->setPixmap(QPixmap(":/images/green.png"));
         ui->label_2->setText(QString("-- ℃"));
    }


    if(humidity!=0)
    {
        if(humidity_alarm<humidity)
        {
            ui->label_6->setPixmap(QPixmap(":/images/red.png"));
            ui->label_4->setText("<span style='color: red;'>"+QString::number(humidity,'f',1)+"</span>%");

        }
        else{
            ui->label_6->setPixmap(QPixmap(":/images/green.png"));
           ui->label_4->setText(QString::number(humidity,'f',1)+"%");
        }


    }
    else
    {
        ui->label_6->setPixmap(QPixmap(":/images/green.png"));
        ui->label_4->setText(QString("-- %"));
    }

    if(smoke!=0)
    {
        if(smoke_alarm<smoke)
        {
            ui->label_6->setPixmap(QPixmap(":/images/red.png"));
           ui->label_9->setText("：<span style='color: red;'>"+QString::number(smoke,'f',2)+"</span>%");

        }
        else{
             ui->label_6->setPixmap(QPixmap(":/images/green.png"));
            ui->label_9->setText(QString::number(smoke,'f',2)+"%");
        }
    }

    else
    {
         ui->label_6->setPixmap(QPixmap(":/images/green.png"));
        ui->label_9->setText(QString("-- %"));
    }

    if(waterLevel!=0)
    {
        if(waterLevel_alarm<waterLevel)
        {
            ui->label_10->setPixmap(QPixmap(":/images/red.png"));
           ui->label_13->setText("<span style='color: red;'>"+QString::number(waterLevel,'f',2)+"</span>%");

        }
        else{
            ui->label_10->setPixmap(QPixmap(":/images/green.png"));
            ui->label_13->setText(QString::number(waterLevel,'f',2)+"%");
        }

    }
    else{
        ui->label_10->setPixmap(QPixmap(":/images/green.png"));
        ui->label_13->setText(QString("-- %"));
    }


    if(strain_alarm<strain1||strain1dialogflag)
    {
        logo1->setPixmap(QPixmap(":/images/red.png"));
      ui->label_21->setText("<span style='color: red;'>"+QString::number(strain1,'f',3)+"</span>");

    }
    else{
        logo1->setPixmap(QPixmap(":/images/green.png"));
        ui->label_21->setText(QString::number(strain1,'f',3));
    }

    if(strain_alarm<strain2||strain2dialogflag)
    {
        logo2->setPixmap(QPixmap(":/images/red.png"));
      ui->label_19->setText("<span style='color: red;'>"+QString::number(strain2,'f',3)+"</span>");

    }
    else{
        logo2->setPixmap(QPixmap(":/images/green.png"));
        ui->label_19->setText(QString::number(strain2,'f',3));
    }

    if(strain2dialogflag||strain1dialogflag)
    {
        ui->templogo_3->setPixmap(QPixmap(":/images/red.png"));
    }
    else{
        ui->templogo_3->setPixmap(QPixmap(":/images/green.png"));
    }

}

void my_widget_form::update_myAlarmWidget(double waterLevel, double humidity, double temperature, double smoke, double strain1,double strain2)
{


    if(waterLevel_alarm<waterLevel)
    {
        AlarmDialog *dialog=new AlarmDialog(QString("当前水位："), QString::number(waterLevel,'f',2)+"%","系统检测到隧道当前水位变化\n请立即采取行动", this);
        dialogshow=true;
        int x =(this->width() - dialog->width()) / 2;
        int y = (this->height() - dialog->height()) / 2;
        dialog->move(x,y);
        dialog->show();
    }
    if(humidity_alarm<humidity)
    {
        AlarmDialog *dialog=new AlarmDialog(QString("当前湿度："), QString::number(humidity,'f',1)+"%","系统检测到隧道当前湿度变化\n请立即采取行动", this);
        dialogshow=true;
        int x =(this->width() - dialog->width()) / 2;
        int y = (this->height() - dialog->height()) / 2;
        dialog->move(x,y);
       dialog->show();
    }

    if(temperature_alarm<temperature)
    {
        AlarmDialog *dialog=new AlarmDialog(QString("当前温度："), QString::number(temperature,'f',1)+"℃","系统检测到隧道当前温度变化\n请立即采取行动", this);
        dialogshow=true;
        int x =(this->width() - dialog->width()) / 2;
        int y = (this->height() - dialog->height()) / 2;
        dialog->move(x,y);
        dialog->show();
    }

    if(smoke_alarm<smoke)
    {
        AlarmDialog *dialog=new AlarmDialog(QString("烟雾浓度："), QString::number(smoke,'f',2)+"%","系统检测到隧道烟雾变化\n请立即采取行动", this);
        dialogshow=true;
        int x =(this->width() - dialog->width()) / 2;
        int y = (this->height() - dialog->height()) / 2;
        dialog->move(x,y);
        dialog->show();
    }
    if(strain_alarm<strain1&&!strain1dialogflag)
    {
        AlarmDialog *dialog=new AlarmDialog(QString("当前应变1："), QString::number(strain1,'f',3),"系统检测到隧道监测点1变化\n请立即采取行动", this);
        strain1dialogflag=true;
        connect(dialog,&AlarmDialog::closeAlarm,[this](){
            strain1dialogflag=false;
        });
        dialogshow=true;
        int x =(this->width() - dialog->width()) / 2;
        int y = (this->height() - dialog->height()) / 2;
        dialog->move(x,y);
        dialog->show();
    }

    if(strain_alarm<strain2&&!strain2dialogflag)
    {
        AlarmDialog *dialog=new AlarmDialog(QString("当前应变2："), QString::number(strain2,'f',3),"系统检测到隧道监测点2变化\n请立即采取行动", this);
        strain2dialogflag=true;
        connect(dialog,&AlarmDialog::closeAlarm,[this](){
            strain2dialogflag=false;
        });
        int x =(this->width() - dialog->width()) / 2;
        int y = (this->height() - dialog->height()) / 2;
        dialog->move(x,y);
        dialog->show();
    }
    dialogshow=false;

}
void my_widget_form::parse_wavelength_data(QByteArray data)
{

    static int count=0;
        if (data.length() < 66) {
            //printf("Received data is too short to parse wavelength data.\n");
            qDebug() <<"Received data is too short to parse wavelength data";
            return;
        }
        //printf("Wavelength data:\n");
        uint16_t wavelength;
        for (int i = 0; i < (data.length()-4)/2-1; ++i) {
             wavelength= (data[4 + i * 2]&0xff) |( (data[4 + i * 2 + 1]&0xff) << 8);
            float wavelength_value = wavelength / 1000.0 + 1520;
            if(i==0)
            {
                if(!pointList_w.isEmpty())
                {
                    double lastw=pointList_w.last().y();
                    strain1=wavelength_value-lastw;
                }
                pointList_w.append(QPointF(count++,wavelength_value));
                update_W_Line();
                if(!strain1dialogflag){
                    update_myAlarmWidget(0,0,0,0,strain1,strain2);
                }
            }
            else if(i==1)
            {
                if(!pointList_i.isEmpty())
                {
                    double lastw=pointList_i.last().y();
                    strain2=wavelength_value-lastw;
                }
                pointList_i.append(QPointF(count-1,wavelength_value));
                qDebug() <<"Wavelength"<<i + 1<<":"<<wavelength_value;
                update_I_Line();
                if(!strain2dialogflag){
                    update_myAlarmWidget(0,0,0,0,strain1,strain2);
                }
                emit on_Publisher_Strain(strain1,strain2);
                break;
            }
            //
            update_myWidget(waterLevel,humidity,temperature,smoke,strain1,strain2);

            //printf("Wavelength %d: %.3f nm\n", i + 1, wavelength_value);
            //qDebug() <<"Wavelength"<<i + 1<<":"<<wavelength_value;
        }

}

void my_widget_form::parse_intensity_data(QByteArray data)
{
    static int count=0;
        if (data.length() < 66) {
            //printf("Received data is too short to parse intensity data.\n");
            qDebug() <<"Received data is too short to parse intensity data";
            return;
        }
}
void my_widget_form::init_wavelength_widget()
{
    chart_w = new QChart();
    chart_w->setBackgroundVisible(false);
    this->setAttribute(Qt::WA_TranslucentBackground);
    chart_w->layout()->setContentsMargins(0, 0, 0, 0);//设置外边界全部为0
    chart_w->setMargins(QMargins(0, 0, 0, 0));//设置内边界全部为0
    chart_w->setBackgroundRoundness(0);//设置背景区域无圆角

        series_w = new QSplineSeries();
//        series_w_2=new QSplineSeries();
        chartview_w = new QChartView();

        //设置图标标题
//        chart_w->setTitle("波长");

        //曲线属性
        series_w->setName(tr("监测点 1"));
        series_w->setColor(QColor(242, 186, 2));

        series_w->setPen(QPen(QColor(242, 186, 2), 2));
        chart_w->addSeries(series_w);

//        series_w_2->setName(tr("波长 2"));
//        series_w_2->setColor(Qt::blue);
//        series_w_2->setPen(QPen(Qt::blue, 2));
//        chart_w->addSeries(series_w_2);

        //设置X轴属性
        QValueAxis *axisX = new QValueAxis;
        chart_w->addAxis(axisX, Qt::AlignBottom);
        //axisX->setTickCount(5);
        axisX->setRange(0, 10);
        axisX->setTitleText("10组");
        series_w->attachAxis(axisX);

        //设置Y轴属性
        QValueAxis *axisY = new QValueAxis;
        chart_w->addAxis(axisY, Qt::AlignLeft);
        axisY->setRange(1400, 1600);
        axisY->setTitleText("波长");
        series_w->attachAxis(axisY);

        update_W_Line();

        //将图标添加到chartview中
        ui->widget_13->setChart(chart_w);
        // 设置X轴颜色
        chart_w->axisX()->setLabelsColor(Qt::white);
        // 设置Y轴颜色
        chart_w->axisY()->setLabelsColor(Qt::white);

        chart_w->setTitleBrush(Qt::green);


}





void my_widget_form::init_intensity_widget()
{
    chart_i = new QChart();
    chart_i->setBackgroundVisible(false);

    chart_i->layout()->setContentsMargins(0, 0, 0, 0);//设置外边界全部为0
    chart_i->setMargins(QMargins(0, 0, 0, 0));//设置内边界全部为0
    chart_i->setBackgroundRoundness(0);//设置背景区域无圆角


    this->setAttribute(Qt::WA_TranslucentBackground);
        series_i = new QSplineSeries();
        series_i->setUseOpenGL(true);  // 使用 OpenGL 渲染以提高性能和显示效果

//        series_i_2=new QSplineSeries();
        chartview_i = new QChartView();

        //设置图标标题
//        chart_w->setTitle("波长");

        //曲线属性
        series_i->setName(tr("监测点 2"));
        series_i->setColor(QColor(238, 130, 47));
        series_i->setPen(QPen(QColor(238, 130, 47), 2));
        chart_i->addSeries(series_i);

//        series_i_2->setName(tr("强度2"));
//        series_i_2->setColor(Qt::yellow);
//        series_i_2->setPen(QPen(Qt::yellow, 2));
//        chart_i->addSeries(series_i_2);

        //设置X轴属性
        QValueAxis *axisX = new QValueAxis;
        chart_i->addAxis(axisX, Qt::AlignBottom);
        //axisX->setTickCount(5);
        axisX->setRange(0, 10);
        axisX->setTitleText("10组");
        series_i->attachAxis(axisX);

        //设置Y轴属性
        QValueAxis *axisY = new QValueAxis;
        chart_i->addAxis(axisY, Qt::AlignLeft);
        axisY->setRange(1400, 1600);
        axisY->setTitleText("波长");
        series_i->attachAxis(axisY);

        update_W_Line();

        //将图标添加到chartview中
        ui->widget_14->setChart(chart_i);
        // 设置X轴颜色
        chart_i->axisX()->setLabelsColor(Qt::white);
        // 设置Y轴颜色
        chart_i->axisY()->setLabelsColor(Qt::white);


}


void my_widget_form::getMaxMinY(const QList<QPointF> &pointList1,double &maxY,double &minY) {


    for (const QPointF &point : pointList1) {
        if (point.y() < minY) {
            minY = point.y();
        }
        if (point.y() > maxY) {
            maxY = point.y();
        }
    }


}
// 打印列表中的每个点


void my_widget_form::update_W_Line()
{

    if(!pointList_w.isEmpty())
    {
        chart_w->axisX()->setMin(pointList_w.first().x());
        chart_w->axisX()->setMax(pointList_w.last().x());
        double maxy=pointList_w.first().y();
        double miny=pointList_w.first().y();
        getMaxMinY(pointList_w,maxy,miny);

        if(pointList_w.last().y()-w_maxy>1||w_miny-pointList_w.last().y()>1)
        {
            w_maxy=pointList_w.last().y()+0.2;
            w_miny=pointList_w.last().y()-0.2;
        }

        if(maxy>w_maxy)//重新赋值
        {
            w_maxy=maxy;
        }
        if(miny<w_miny)
        {
            w_miny=miny;
        }

        const double epsilon = 1e-10;
        double offset=0;
        if(w_maxy-w_miny<epsilon){
            offset=1;
        }
        chart_w->axisY()->setMax(w_maxy+0.1*(w_maxy-w_miny)+offset);
        chart_w->axisY()->setMin(w_miny-0.1*(w_maxy-w_miny)-offset);


//        for (const QPointF &point : pointList_w) {
//            qDebug() << "(" << point.x() << ", " << point.y() << ")";
//        }
        series_w->clear();

        series_w->append(pointList_w);

        if(pointList_w.size()>100)
        {

            pointList_w.removeFirst();
        }
    }



}

void my_widget_form::update_I_Line()
{
    if(!pointList_i.isEmpty())
    {
        chart_i->axisX()->setMin(pointList_i.first().x());
        chart_i->axisX()->setMax(pointList_i.last().x());
        double maxy=pointList_i.first().y();
        double miny=pointList_i.first().y();
        getMaxMinY(pointList_i,maxy,miny);

        if(pointList_i.last().y()-i_maxy>1||i_miny-pointList_i.last().y()>1)
        {
            i_maxy=pointList_i.last().y()+0.2;
            i_miny=pointList_i.last().y()-0.2;
        }

        if(maxy>i_maxy)//重新赋值
        {
            i_maxy=maxy;
        }
        if(miny<i_miny)
        {
            i_miny=miny;
        }

        const double epsilon = 1e-10;
        double offset=0;
        if(i_maxy-i_miny<epsilon){
            offset=1;
        }
        chart_i->axisY()->setMax(i_maxy+0.1*(i_maxy-i_miny)+offset);
        chart_i->axisY()->setMin(i_miny-0.1*(i_maxy-i_miny)-offset);


//        for (const QPointF &point : pointList_w) {
//            qDebug() << "(" << point.x() << ", " << point.y() << ")";
//        }
        series_i->clear();

        series_i->append(pointList_i);

        if(pointList_i.size()>100)
        {

            pointList_i.removeFirst();
        }
    }


}
