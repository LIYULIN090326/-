﻿#include "frmmain.h"
#include "quiwidget.h"
#include "my_widget_form.h"

#include "my_mqtt.h"
#include "udpserver.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    a.setWindowIcon(QIcon(":/main.ico"));

    QFont font;
    font.setFamily(QUIConfig::FontName);
    font.setPixelSize(QUIConfig::FontSize);
    a.setFont(font);

    //设置编码以及加载中文翻译文件
    QUIHelper::setCode();
    QUIHelper::setTranslator(":/qt_zh_CN.qm");
    QUIHelper::setTranslator(":/widgets.qm");
    QUIHelper::initRand();

    App::Intervals << "1" << "10" << "20" << "50" << "100" << "200" << "300" << "500" << "1000" << "1500" << "2000" << "3000" << "5000" << "10000";
    App::ConfigFile = QString("%1/%2.ini").arg(QUIHelper::appPath()).arg(QUIHelper::appName());
    App::readConfig();
    App::readSendData();
    App::readDeviceData();

    udpServer udp;

    my_mqtt mqtt;

    frmMain fw;
    fw.setWindowTitle(QString("智慧隧道监测预警系统  本机IP: %1  ").arg(QUIHelper::getLocalIP()));
    fw.hide();


    my_widget_form w;
    w.show();



    QObject::connect(&mqtt,&my_mqtt::send_data,&fw,&frmMain::get_data);

    QObject::connect(&mqtt,&my_mqtt::send_data,&w,&my_widget_form::get_data);

    QObject::connect(&w,&my_widget_form::on_Publisher_Strain,&mqtt,&my_mqtt::on_Publisher_Strain);

    QObject::connect(&udp,&udpServer::parse_wavelength_data_sig,&w,&my_widget_form::parse_wavelength_data);
    QObject::connect(&udp,&udpServer::parse_intensity_data_sig,&w,&my_widget_form::parse_intensity_data);



    QObject::connect(&udp,&udpServer::parse_wavelength_data_sig,&fw,&frmMain::parse_wavelength_data);
    QObject::connect(&udp,&udpServer::parse_intensity_data_sig,&fw,&frmMain::parse_intensity_data);



    QObject::connect(&fw,&frmMain::listen_sig,&udp,&udpServer::listen);
    //QObject::connect(&fw,&frmMain::send_data_sig,&udp,&udpServer::sendData);


    QObject::connect(&w,&my_widget_form::listen_sig,&udp,&udpServer::listen);
    //QObject::connect(&w,&my_widget_form::sendData,&udp,&udpServer::sendData);



    QObject::connect(&fw,&frmMain::frmMain_hide,[&w](){
        w.show();
    });
    QObject::connect(&w,&my_widget_form::my_widget_form_hide,[&fw](){
        fw.show();
    });


    return a.exec();
}



