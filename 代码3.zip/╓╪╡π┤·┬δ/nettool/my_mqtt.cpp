#include "my_mqtt.h"
#include <QMessageAuthenticationCode>
#include <QJsonDocument>
#include <QJsonObject>
#include "qmqtt_message.h"
my_mqtt::my_mqtt(QObject *parent) : QObject(parent)
{
    init_mqtt();
}

void my_mqtt::init_mqtt()
{
    m_strProductKey="a1J61Wvmk5p";  //需要跟阿里云Iot平台一致;
    m_strDeviceName="qt_Dev";   //需要跟阿里云Iot平台一致;
    m_strDeviceSecret="dd76cde8e0d2f612dbdd5b1cd76c1326";   //需要跟阿里云平台一致
    m_strRegionId="cn-shanghai";

    m_strPubTopic = "/sys/" + m_strProductKey + "/" + m_strDeviceName + "/thing/event/property/post";//发布topic
    m_strSubTopic = "/sys/" + m_strProductKey + "/" + m_strDeviceName + "/thing/service/property/set";//订阅topic
    m_strTargetServer = m_strProductKey + ".iot-as-mqtt." + m_strRegionId + ".aliyuncs.com";//域名

    QString clientId="1234567";         //表示客户端ID，建议使用设备的MAC地址或SN码，64字符内。
    QString signmethod = "hmacsha1";    //加密方式
    QString message ="clientId"+clientId+"deviceName"+m_strDeviceName+"productKey"+m_strProductKey;

    m_client=new QMQTT::Client();
    m_client->setHostName(m_strTargetServer);
    m_client->setPort(1883);


    m_client->setUsername(m_strDeviceName + "&" + m_strProductKey);
    m_client->setClientId(clientId + "|securemode=3,signmethod=" + signmethod + "|");
    m_client->setPassword(QMessageAuthenticationCode::hash(message.toLocal8Bit(),
                                                           m_strDeviceSecret.toLocal8Bit(),
                                                           QCryptographicHash::Sha1).toHex());
    m_client->connectToHost();//连接阿里云

    connect(m_client, &QMQTT::Client::connected, this, &my_mqtt::connected);
    connect(m_client,SIGNAL(received(const QMQTT::Message&)),this,SLOT(onMQTT_Received(const QMQTT::Message&)));
    connect(m_client,SIGNAL(subscribed(const QString&)),this,SLOT(onMQTT_subscribed(const QString&)));
    connect(m_client, &QMQTT::Client::disconnected, this, &my_mqtt::disconnected);

}
void my_mqtt::disconnected()
{
    qDebug() << "disconnect";
}

void my_mqtt::connected()
{
    qDebug() << "connected";
   m_client->subscribe(m_strSubTopic);
   //on_Publisher_Strain(1.01);
}

void my_mqtt::on_Publisher_Strain(double value1,double value2)
{
    QString payload2 ;
    QJsonObject paramsObject;
     paramsObject["Strain1"] = value1;
     paramsObject["Strain2"] = value2;

     QJsonObject rootObject;
     rootObject["method"] = "thing.event.property.post";
     rootObject["id"] = "1376401144";
     rootObject["params"] = paramsObject;
     rootObject["version"] = "1.0.0";

     QJsonDocument doc(rootObject);
    payload2=doc.toJson(QJsonDocument::Compact);


    QMQTT::Message message(12580, m_strPubTopic, payload2.toLocal8Bit());

    qDebug() <<message.id();
    qDebug() << message.topic();
    qDebug() << message.payload();
    //发布消息
    m_client->publish(message);
}

void my_mqtt::onMQTT_subscribed(const QString &topic)
{
    // 订阅成功后的处理
    qDebug() << "subscribe success:" << topic;
//    QMessageBox::warning(this,"订阅成功",topic,QMessageBox::Yes);
}
void my_mqtt::onMQTT_Received(const QMQTT::Message &message)
{
    // 接受到服务器消息时的处理
    qDebug() << "message.id="<<message.id();
    qDebug() << "message.topic="<<message.topic();
    qDebug() << "message.payload="<<message.payload();

    QString payload = message.payload();
    parseJson(payload);
    if(payload.contains("set", Qt::CaseSensitive))
    {
        qDebug() << "set";
    }

}
void my_mqtt::parseJson(const QString& jsonString) {
    QJsonDocument doc = QJsonDocument::fromJson(jsonString.toUtf8());
    if (!doc.isNull() && doc.isObject()) {
        QJsonObject obj = doc.object();
        QString method = obj.value("method").toString();
        QJsonObject paramsObj = obj.value("params").toObject();

         waterLevel = paramsObj.value("WaterLevel").toDouble();
         humidity = paramsObj.value("Humidity").toDouble();
         temperature = paramsObj.value("temperature").toDouble();
         smoke = paramsObj.value("Smoke").toDouble();
         //strain = paramsObj.value("Strain").toDouble();

       // update_myWidget(waterLevel,humidity,temperature,smoke,strain1,strain2);
       // update_myAlarmWidget(waterLevel,humidity,temperature,smoke,strain1,strain2);
        qDebug() << "Method: " << method;
        qDebug() << "WaterLevel: " << waterLevel;
        qDebug() << "Humidity: " << humidity;
        qDebug() << "Temperature: " << temperature;
        qDebug() << "Smoke: " << smoke;
        qDebug() << "Strain: " << strain1;

        emit send_data(QString("%1-%2-%3-%4").arg(waterLevel).arg(humidity).arg(temperature).arg(smoke));

    } else {
        qDebug() << "Invalid JSON string";
    }

}
