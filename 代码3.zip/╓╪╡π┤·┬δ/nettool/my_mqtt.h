#ifndef MY_MQTT_H
#define MY_MQTT_H

#include <QObject>
#include "qmqtt_client.h"
class my_mqtt : public QObject
{
    Q_OBJECT
public:
    explicit my_mqtt(QObject *parent = nullptr);

    void init_mqtt();

public slots:
    void connected();
    void on_Publisher_Strain(double value1,double value2);
    void onMQTT_Received(const QMQTT::Message &message);
    void onMQTT_subscribed(const QString& topic);
    void disconnected();
    void parseJson(const QString& jsonString);

private:
    QMQTT::Client *m_client;
    quint16 EXAMPLE_PORT;
    QString EXAMPLE_TOPIC ;//= "qmqtt/exampletopic"
    QString m_strProductKey;//="xxxxx";  //需要跟阿里云Iot平台一致;
    QString m_strDeviceName;//="xxxxx";   //需要跟阿里云Iot平台一致;
    QString m_strDeviceSecret;//="xxxxx";   //需要跟阿里云平台一致
    QString m_strRegionId;//="cn-shanghai";

    QString m_strPubTopic;// = "/sys/" + m_strProductKey + "/" + m_strDeviceName + "/thing/event/property/post";//发布topic
    QString m_strSubTopic;// = "/sys/" + m_strProductKey + "/" + m_strDeviceName + "/thing/service/property/set";//订阅topic
    QString m_strTargetServer;// = m_strProductKey + ".iot-as-mqtt." + m_strRegionId + ".aliyuncs.com";//域名



    double waterLevel=0;
    double humidity=0;
    double temperature=0;
    double smoke=0;
    double strain1=0;
    double strain2=0;



signals:
    void send_data(QString);
};

#endif // MY_MQTT_H
