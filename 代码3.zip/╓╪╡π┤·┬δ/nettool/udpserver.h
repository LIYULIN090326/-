#ifndef UDPSERVER_H
#define UDPSERVER_H

#include <QObject>
#include <QtNetwork>
#include <QUdpSocket>

class udpServer : public QObject
{
    Q_OBJECT
public:
    explicit udpServer(QObject *parent = nullptr);

    void initUpServer();
    void append(int type, const QString &data, bool clear = false);
    void sendData(const QString &ip, int port, const QString &data);
private:


signals:
    void parse_wavelength_data_sig(QByteArray);
    void parse_intensity_data_sig(QByteArray);
    void send_data_to_display(int,QString);
public slots:
    void readData();
    void deal_data(QByteArray data);
    void listen(bool flag);

};

#endif // UDPSERVER_H
