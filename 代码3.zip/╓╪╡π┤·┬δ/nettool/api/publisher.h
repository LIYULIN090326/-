#ifndef PUBLISHER_H
#define PUBLISHER_H



#include "qmqtt_client.h"
#include "qmqtt_message.h"
#include <QObject>
#include <QTimer>
const QHostAddress EXAMPLE_HOST = QHostAddress("139.224.42.2");
const quint16 EXAMPLE_PORT = 1883;
const QString EXAMPLE_TOPIC = "qmqtt/exampletopic";

class Publisher : public QMQTT::Client
{
    Q_OBJECT
public:
    explicit Publisher(const QHostAddress& host = EXAMPLE_HOST,
                       const quint16 port = EXAMPLE_PORT,
                       QObject* parent = nullptr);
    virtual ~Publisher();

public slots:
    void onConnected();
    void onTimeout();
    void onDisconnected();

private:
    QTimer _timer;
    quint16 _number;
};


#endif // PUBLISHER_H
