#include "publisher.h"

Publisher::Publisher(const QHostAddress& host,
                     const quint16 port,
                     QObject* parent)
    : QMQTT::Client(host, port, parent)
   , _number(0)
{
    connect(this, &Publisher::connected, this, &Publisher::onConnected);
    connect(&_timer, &QTimer::timeout, this, &Publisher::onTimeout);
    connect(this, &Publisher::disconnected, this, &Publisher::onDisconnected);
}

Publisher::~Publisher() {}

void Publisher::onConnected()
{
    subscribe(EXAMPLE_TOPIC, 0);
    _timer.start(1000);
}

void Publisher::onTimeout()
{
    QMQTT::Message message(_number, EXAMPLE_TOPIC,
                           QString("Number is %1").arg(_number).toUtf8());
    publish(message);
    _number++;
    if(_number >= 10)
    {
        _timer.stop();
        disconnectFromHost();
    }
}

void Publisher::onDisconnected()
{
    //QTimer::singleShot(0, qApp, &QCoreApplication::quit);
}
