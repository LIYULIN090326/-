#ifndef SUBSCRIBER_H
#define SUBSCRIBER_H

#include "qmqtt_client.h"
#include "qmqtt_message.h"
#include <QObject>
#include <QTextStream>
#include "Publisher.h"
class Subscriber : public QMQTT::Client
{
    Q_OBJECT
public:
    explicit Subscriber(const QHostAddress& host = EXAMPLE_HOST,
                        const quint16 port = EXAMPLE_PORT,
                        QObject* parent = nullptr);
    virtual ~Subscriber();

public slots:
    void onConnected();
    void onSubscribed(const QString& topic);
    void onReceived(const QMQTT::Message& message);

private:
    QTextStream _qout;
};

#endif // SUBSCRIBER_H
