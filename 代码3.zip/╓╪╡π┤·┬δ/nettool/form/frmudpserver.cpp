﻿#include "frmudpserver.h"
#include "ui_frmudpserver.h"
#include "quiwidget.h"
#include "udpserver.h"
extern  QUdpSocket *udpSocket;
frmUdpServer::frmUdpServer(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::frmUdpServer)
{
    ui->setupUi(this);
    dialogshow=false;
     strain1dialogflag=false;
     strain2dialogflag=false;
    this->initForm();
    this->initConfig();
//    pointList_w.append(QPointF(0,0));
//    pointList_i.append(QPointF(0,0));
//    pointList_w_2.append(QPointF(0,0));
//    pointList_i_2.append(QPointF(0,0));
    this->init_wavelength_widget();
    this->init_intensity_widget();

    update_myWidget(0,0,0,0,0,0);
}

frmUdpServer::~frmUdpServer()
{
    delete ui;
}

void frmUdpServer::initForm()
{
//    udpSocket = new QUdpSocket(this);
//    connect(udpSocket, SIGNAL(readyRead()), this, SLOT(readData()));

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(on_btnSend_clicked()));

    timer1=new QTimer(this);
    connect(timer1, SIGNAL(timeout()), this, SLOT(update_W_Line()));



    ui->cboxInterval->addItems(App::Intervals);
    ui->cboxData->addItems(App::Datas);

}

void frmUdpServer::initConfig()
{
    ui->ckHexSend->setChecked(App::HexSendUdpServer);
    connect(ui->ckHexSend, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));

    ui->ckHexReceive->setChecked(App::HexReceiveUdpServer);
    connect(ui->ckHexReceive, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));

    ui->ckAscii->setChecked(App::AsciiUdpServer);
    connect(ui->ckAscii, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));

    ui->ckDebug->setChecked(App::DebugUdpServer);
    connect(ui->ckDebug, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));

    ui->ckAutoSend->setChecked(App::AutoSendUdpServer);
    connect(ui->ckAutoSend, SIGNAL(stateChanged(int)), this, SLOT(saveConfig()));

    ui->cboxInterval->setCurrentIndex(ui->cboxInterval->findText(QString::number(App::IntervalUdpServer)));
    connect(ui->cboxInterval, SIGNAL(currentIndexChanged(int)), this, SLOT(saveConfig()));

    ui->txtServerIP->setText(App::UdpServerIP);
    connect(ui->txtServerIP, SIGNAL(textChanged(QString)), this, SLOT(saveConfig()));

    ui->txtServerPort->setText(QString::number(App::UdpServerPort));
    connect(ui->txtServerPort, SIGNAL(textChanged(QString)), this, SLOT(saveConfig()));

    ui->txtListenPort->setText(QString::number(App::UdpListenPort));
    connect(ui->txtListenPort, SIGNAL(textChanged(QString)), this, SLOT(saveConfig()));

    timer->setInterval(App::IntervalUdpServer);
    App::AutoSendUdpServer ? timer->start() : timer->stop();
}

void frmUdpServer::saveConfig()
{
    App::HexSendUdpServer = ui->ckHexSend->isChecked();
    App::HexReceiveUdpServer = ui->ckHexReceive->isChecked();
    App::AsciiUdpServer = ui->ckAscii->isChecked();
    App::DebugUdpServer = ui->ckDebug->isChecked();
    App::AutoSendUdpServer = ui->ckAutoSend->isChecked();
    App::IntervalUdpServer = ui->cboxInterval->currentText().toInt();
    App::UdpServerIP = ui->txtServerIP->text().trimmed();
    App::UdpServerPort = ui->txtServerPort->text().trimmed().toInt();
    App::UdpListenPort = ui->txtListenPort->text().trimmed().toInt();
    App::writeConfig();

    timer->setInterval(App::IntervalUdpServer);
    App::AutoSendUdpServer ? timer->start() : timer->stop();
}

void frmUdpServer::init_wavelength_widget()
{
    chart_w = new QChart();
        series_w = new QSplineSeries();
//        series_w_2=new QSplineSeries();
        chartview_w = new QChartView();

        //设置图标标题
//        chart_w->setTitle("波长");

        //曲线属性
        series_w->setName(tr("监测点 1"));
        series_w->setColor(Qt::green);
        series_w->setPen(QPen(Qt::green, 2));
        chart_w->addSeries(series_w);

//        series_w_2->setName(tr("波长 2"));
//        series_w_2->setColor(Qt::blue);
//        series_w_2->setPen(QPen(Qt::blue, 2));
//        chart_w->addSeries(series_w_2);

        //设置X轴属性
        QValueAxis *axisX = new QValueAxis;
        chart_w->addAxis(axisX, Qt::AlignBottom);
        //axisX->setTickCount(5);
        axisX->setRange(0, 10);
        axisX->setTitleText("10组");
        series_w->attachAxis(axisX);

        //设置Y轴属性
        QValueAxis *axisY = new QValueAxis;
        chart_w->addAxis(axisY, Qt::AlignLeft);
        axisY->setRange(1400, 1600);
        axisY->setTitleText("波长");
        series_w->attachAxis(axisY);

        update_W_Line();

        //将图标添加到chartview中
        ui->widget_2->setChart(chart_w);

}



void frmUdpServer::init_intensity_widget()
{
    chart_i = new QChart();
        series_i = new QSplineSeries();
//        series_i_2=new QSplineSeries();
        chartview_i = new QChartView();

        //设置图标标题
//        chart_w->setTitle("波长");

        //曲线属性
        series_i->setName(tr("监测点 2"));
        series_i->setColor(Qt::yellow);
        series_i->setPen(QPen(Qt::yellow, 2));
        chart_i->addSeries(series_i);

//        series_i_2->setName(tr("强度2"));
//        series_i_2->setColor(Qt::yellow);
//        series_i_2->setPen(QPen(Qt::yellow, 2));
//        chart_i->addSeries(series_i_2);

        //设置X轴属性
        QValueAxis *axisX = new QValueAxis;
        chart_i->addAxis(axisX, Qt::AlignBottom);
        //axisX->setTickCount(5);
        axisX->setRange(0, 10);
        axisX->setTitleText("10组");
        series_i->attachAxis(axisX);

        //设置Y轴属性
        QValueAxis *axisY = new QValueAxis;
        chart_i->addAxis(axisY, Qt::AlignLeft);
        axisY->setRange(1400, 1600);
        axisY->setTitleText("波长");
        series_i->attachAxis(axisY);

        update_W_Line();

        //将图标添加到chartview中
        ui->widget_3->setChart(chart_i);
}



void frmUdpServer::update_myWidget(double waterLevel, double humidity, double temperature, double smoke, double strain1,double strain2)
{
    if(temperature!=0)
    {
        if(temperature_alarm<temperature)
        {

           ui->label_1->setText("温度：<span style='color: red;'>"+QString::number(temperature,'f',1)+"</span>℃");
        }
        else{

            ui->label_1->setText("温度："+QString::number(temperature,'f',1)+"℃");
        }
    }
    else
    {

         ui->label_1->setText(QString("温度：--- ℃"));
    }
    if(humidity!=0)
    {
        if(humidity_alarm<humidity)
        {
            ui->label_2->setText("湿度：<span style='color: red;'>"+QString::number(humidity,'f',1)+"</span>%");

        }
        else{
           ui->label_2->setText("湿度："+QString::number(humidity,'f',1)+"%");
        }


    }
    else
    {
        ui->label_2->setText(QString("湿度：--- %"));
    }
    if(smoke!=0)
    {
        if(smoke_alarm<smoke)
        {
           ui->label_3->setText("烟雾浓度：<span style='color: red;'>"+QString::number(smoke,'f',2)+"</span>%");

        }
        else{
            ui->label_3->setText("烟雾浓度："+QString::number(smoke,'f',2)+"%");
        }
    }
    else
    {
        ui->label_3->setText(QString("烟雾浓度：--- %"));
    }
    if(waterLevel!=0)
    {
        if(waterLevel_alarm<waterLevel)
        {
           ui->label_4->setText("水位：<span style='color: red;'>"+QString::number(waterLevel,'f',2)+"</span>%");

        }
        else{
            ui->label_4->setText("水位："+QString::number(waterLevel,'f',2)+"%");
        }

    }
    else{
        ui->label_4->setText(QString("水位：--- %"));
    }
    if(strain_alarm<strain1||strain1dialogflag)
    {
      ui->label_5->setText("应变1：<span style='color: red;'>"+QString::number(strain1,'f',3)+"</span>");

    }
    else{
        ui->label_5->setText("应变1："+QString::number(strain1,'f',3));
    }

    if(strain_alarm<strain2||strain2dialogflag)
    {
      ui->label_6->setText("应变2：<span style='color: red;'>"+QString::number(strain2,'f',3)+"</span>");

    }
    else{
        ui->label_6->setText("应变2："+QString::number(strain2,'f',3));
    }


}

void frmUdpServer::update_myAlarmWidget(double waterLevel, double humidity, double temperature, double smoke, double strain1,double strain2)
{


    if(waterLevel_alarm<waterLevel)
    {
        AlarmDialog *dialog=new AlarmDialog(QString("当前水位："), QString::number(waterLevel,'f',2)+"%","系统检测到隧道当前水位变化\n请立即采取行动", this);
        dialogshow=true;
        int x =(this->width() - dialog->width()) / 2;
        int y = (this->height() - dialog->height()) / 2;
        dialog->move(x,y);
        dialog->show();
    }
    if(humidity_alarm<humidity)
    {
        AlarmDialog *dialog=new AlarmDialog(QString("当前湿度："), QString::number(humidity,'f',1)+"%","系统检测到隧道当前湿度变化\n请立即采取行动", this);
        dialogshow=true;
        int x =(this->width() - dialog->width()) / 2;
        int y = (this->height() - dialog->height()) / 2;
        dialog->move(x,y);
       dialog->show();
    }

    if(temperature_alarm<temperature)
    {
        AlarmDialog *dialog=new AlarmDialog(QString("当前温度："), QString::number(temperature,'f',1)+"℃","系统检测到隧道当前温度变化\n请立即采取行动", this);
        dialogshow=true;
        int x =(this->width() - dialog->width()) / 2;
        int y = (this->height() - dialog->height()) / 2;
        dialog->move(x,y);
        dialog->show();
    }

    if(smoke_alarm<smoke)
    {
        AlarmDialog *dialog=new AlarmDialog(QString("烟雾浓度："), QString::number(smoke,'f',2)+"%","系统检测到隧道烟雾变化\n请立即采取行动", this);
        dialogshow=true;
        int x =(this->width() - dialog->width()) / 2;
        int y = (this->height() - dialog->height()) / 2;
        dialog->move(x,y);
        dialog->show();
    }
    if(strain_alarm<strain1&&!strain1dialogflag)
    {
        AlarmDialog *dialog=new AlarmDialog(QString("当前应变1："), QString::number(strain1,'f',3),"系统检测到隧道监测点1变化\n请立即采取行动", this);
        strain1dialogflag=true;
        connect(dialog,&AlarmDialog::closeAlarm,[this](){
            strain1dialogflag=false;
        });
        dialogshow=true;
        int x =(this->width() - dialog->width()) / 2;
        int y = (this->height() - dialog->height()) / 2;
        dialog->move(x,y);
        dialog->show();
    }

    if(strain_alarm<strain2&&!strain2dialogflag)
    {
        AlarmDialog *dialog=new AlarmDialog(QString("当前应变2："), QString::number(strain2,'f',3),"系统检测到隧道监测点2变化\n请立即采取行动", this);
        strain2dialogflag=true;
        connect(dialog,&AlarmDialog::closeAlarm,[this](){
            strain2dialogflag=false;
        });
        int x =(this->width() - dialog->width()) / 2;
        int y = (this->height() - dialog->height()) / 2;
        dialog->move(x,y);
        dialog->show();
    }
    dialogshow=false;

}

void frmUdpServer::append(int type, const QString &data, bool clear)
{
    static int currentCount = 0;
    static int maxCount = 100;

    if (clear) {
        ui->txtMain->clear();
        currentCount = 0;
        return;
    }

    if (currentCount >= maxCount) {
        ui->txtMain->clear();
        currentCount = 0;
    }

    if (ui->ckShow->isChecked()) {
        return;
    }

    //过滤回车换行符
    QString strData = data;
    strData = strData.replace("\r", "");
    strData = strData.replace("\n", "");

    //不同类型不同颜色显示
    QString strType;
    if (type == 0) {
        strType = "发送";
        ui->txtMain->setTextColor(QColor("darkgreen"));
    } else {
        strType = "接收";
        ui->txtMain->setTextColor(QColor("red"));
    }

    strData = QString("时间[%1] %2: %3").arg(TIMEMS).arg(strType).arg(strData);
    ui->txtMain->append(strData);
    currentCount++;
}

void frmUdpServer::deal_data(QByteArray data)
{
    if (data.startsWith(QByteArray::fromHex("01 0C")))
    {
        qDebug() << "以 01 0c 开头，进行相应处理";
        parse_wavelength_data(data);
    }
    else if (data.startsWith(QByteArray::fromHex("01 10")))
    {
        qDebug() << "以 01 10 开头，进行相应处理";
        parse_intensity_data(data);
    }
}

void frmUdpServer::parse_wavelength_data(QByteArray data)
{

    static int count=0;
        if (data.length() < 66) {
            //printf("Received data is too short to parse wavelength data.\n");
            qDebug() <<"Received data is too short to parse wavelength data";
            return;
        }
        //printf("Wavelength data:\n");
        uint16_t wavelength;
        for (int i = 0; i < (data.length()-4)/2-1; ++i) {
             wavelength= (data[4 + i * 2]&0xff) |( (data[4 + i * 2 + 1]&0xff) << 8);
            float wavelength_value = wavelength / 1000.0 + 1520;
            if(i==0)
            {
                if(!pointList_w.isEmpty())
                {
                    double lastw=pointList_w.last().y();
                    strain1=wavelength_value-lastw;
                }
                pointList_w.append(QPointF(count++,wavelength_value));
                update_W_Line();
                if(!strain1dialogflag){
                    //update_myAlarmWidget(0,0,0,0,strain1,strain2);
                }
            }
            else if(i==1)
            {
                if(!pointList_i.isEmpty())
                {
                    double lastw=pointList_i.last().y();
                    strain2=wavelength_value-lastw;
                }
                pointList_i.append(QPointF(count-1,wavelength_value));
                qDebug() <<"Wavelength"<<i + 1<<":"<<wavelength_value;
                update_I_Line();
                if(!strain2dialogflag){
                    //update_myAlarmWidget(0,0,0,0,strain1,strain2);
                }
                break;
            }
            //
            update_myWidget(waterLevel,humidity,temperature,smoke,strain1,strain2);

            //printf("Wavelength %d: %.3f nm\n", i + 1, wavelength_value);
            //qDebug() <<"Wavelength"<<i + 1<<":"<<wavelength_value;
        }

}

void frmUdpServer::parse_intensity_data(QByteArray data)
{
    static int count=0;
        if (data.length() < 66) {
            //printf("Received data is too short to parse intensity data.\n");
            qDebug() <<"Received data is too short to parse intensity data";
            return;
        }
}
void frmUdpServer::getMaxMinY(const QList<QPointF> &pointList1,double &maxY,double &minY) {


    for (const QPointF &point : pointList1) {
        if (point.y() < minY) {
            minY = point.y();
        }
        if (point.y() > maxY) {
            maxY = point.y();
        }
    }


}
// 打印列表中的每个点


void frmUdpServer::update_W_Line()
{

    if(!pointList_w.isEmpty())
    {
        chart_w->axisX()->setMin(pointList_w.first().x());
        chart_w->axisX()->setMax(pointList_w.last().x());
        double maxy=pointList_w.first().y();
        double miny=pointList_w.first().y();
        getMaxMinY(pointList_w,maxy,miny);

        if(pointList_w.last().y()-w_maxy>1||w_miny-pointList_w.last().y()>1)
        {
            w_maxy=pointList_w.last().y()+0.2;
            w_miny=pointList_w.last().y()-0.2;
        }

        if(maxy>w_maxy)//重新赋值
        {
            w_maxy=maxy;
        }
        if(miny<w_miny)
        {
            w_miny=miny;
        }

        const double epsilon = 1e-10;
        double offset=0;
        if(w_maxy-w_miny<epsilon){
            offset=1;
        }
        chart_w->axisY()->setMax(w_maxy+0.1*(w_maxy-w_miny)+offset);
        chart_w->axisY()->setMin(w_miny-0.1*(w_maxy-w_miny)-offset);


//        for (const QPointF &point : pointList_w) {
//            qDebug() << "(" << point.x() << ", " << point.y() << ")";
//        }
        series_w->clear();

        series_w->append(pointList_w);

        if(pointList_w.size()>100)
        {

            pointList_w.removeFirst();
        }
    }



}

void frmUdpServer::update_I_Line()
{
    if(!pointList_i.isEmpty())
    {
        chart_i->axisX()->setMin(pointList_i.first().x());
        chart_i->axisX()->setMax(pointList_i.last().x());
        double maxy=pointList_i.first().y();
        double miny=pointList_i.first().y();
        getMaxMinY(pointList_i,maxy,miny);

        if(pointList_i.last().y()-i_maxy>1||i_miny-pointList_i.last().y()>1)
        {
            i_maxy=pointList_i.last().y()+0.2;
            i_miny=pointList_i.last().y()-0.2;
        }

        if(maxy>i_maxy)//重新赋值
        {
            i_maxy=maxy;
        }
        if(miny<i_miny)
        {
            i_miny=miny;
        }

        const double epsilon = 1e-10;
        double offset=0;
        if(i_maxy-i_miny<epsilon){
            offset=1;
        }
        chart_i->axisY()->setMax(i_maxy+0.1*(i_maxy-i_miny)+offset);
        chart_i->axisY()->setMin(i_miny-0.1*(i_maxy-i_miny)-offset);


//        for (const QPointF &point : pointList_w) {
//            qDebug() << "(" << point.x() << ", " << point.y() << ")";
//        }
        series_i->clear();

        series_i->append(pointList_i);

        if(pointList_i.size()>100)
        {

            pointList_i.removeFirst();
        }
    }


}

void frmUdpServer::get_esp8266_data(QString data)
{
    QStringList list=data.split("-");
     waterLevel=list.at(0).toDouble();
     humidity=list.at(1).toDouble();
     temperature=list.at(2).toDouble();
     smoke=list.at(3).toDouble();
     //update_myAlarmWidget( waterLevel,  humidity,  temperature,  smoke,  strain1, strain2);
     update_myWidget( waterLevel,  humidity,  temperature,  smoke,  strain1, strain2);
}

void frmUdpServer::readData()
{
//    QHostAddress host;
//    quint16 port;
//    QByteArray data;
//    QString buffer;

//    while (udpSocket->hasPendingDatagrams()) {
//        data.resize(udpSocket->pendingDatagramSize());
//        udpSocket->readDatagram(data.data(), data.size(), &host, &port);

//        deal_data(data);

//        if (App::HexReceiveUdpServer) {
//            buffer = QUIHelper::byteArrayToHexStr(data);
//        } else if (App::AsciiUdpServer) {
//            buffer = QUIHelper::byteArrayToAsciiStr(data);
//        } else {
//            buffer = QString(data);
//        }

//        QString ip = host.toString();
//        if (ip.isEmpty()) {
//            continue;
//        }

//        QString str = QString("[%1:%2] %3").arg(ip).arg(port).arg(buffer);
//        append(1, str);

//        if (App::DebugUdpServer) {
//            int count = App::Keys.count();
//            for (int i = 0; i < count; i++) {
//                if (App::Keys.at(i) == buffer) {
//                    sendData(ip, port, App::Values.at(i));
//                    break;
//                }
//            }
//        }
//    }
}

void frmUdpServer::sendData(const QString &ip, int port, const QString &data)
{
    QByteArray buffer;
    if (App::HexSendUdpServer) {
        buffer = QUIHelper::hexStrToByteArray(data);
    } else if (App::AsciiUdpServer) {
        buffer = QUIHelper::asciiStrToByteArray(data);
    } else {
        buffer = data.toLatin1();
    }

    //emit send_data_sig(ip,port,data);
    udpSocket->writeDatagram(buffer, QHostAddress(ip), port);

    QString str = QString("[%1:%2] %3").arg(ip).arg(port).arg(data);
    append(0, str);

}

void frmUdpServer::on_btnListen_clicked()
{
    if (ui->btnListen->text() == "监听") {
        emit listen_sig(true);
//#if (QT_VERSION > QT_VERSION_CHECK(5,0,0))


//        bool ok = udpSocket->bind(QHostAddress::AnyIPv4, App::UdpListenPort);
//#else
//        bool ok = udpSocket->bind(QHostAddress::Any, App::UdpListenPort);
//#endif
//        if (ok) {
//            ui->btnListen->setText("关闭");
            append(0, "监听成功");
//        }
    } else {
        emit listen_sig(false);
//        udpSocket->abort();
        ui->btnListen->setText("监听");
    }
}

void frmUdpServer::on_btnSave_clicked()
{
    QString data = ui->txtMain->toPlainText();
    if (data.length() <= 0) {
        return;
    }

    QString fileName = QString("%1/%2.txt").arg(QUIHelper::appPath()).arg(STRDATETIME);
    QFile file(fileName);
    if (file.open(QFile::WriteOnly | QFile::Text)) {
        file.write(data.toUtf8());
        file.close();
    }

    on_btnClear_clicked();
}

void frmUdpServer::on_btnClear_clicked()
{
    append(0, "", true);
}

void frmUdpServer::on_btnSend_clicked()
{
    QString data = ui->cboxData->currentText();
    if (data.length() <= 0) {
        return;
    }

    sendData(App::UdpServerIP, App::UdpServerPort, data);
}
uint16_t frmUdpServer::crc16(const unsigned char* buf, int len) {
    uint16_t crc = 0xFFFF;
    for (int pos = 0; pos < len; pos++) {
        crc ^= (uint16_t)buf[pos];
        for (int i = 8; i != 0; i--) {
            if ((crc & 0x0001) != 0) {
                crc >>= 1;
                crc ^= 0xA001;
            }
            else {
                crc >>= 1;
            }
        }
    }
    return crc;
}
void frmUdpServer::send_command(unsigned char* command, size_t command_len) {
    uint16_t crc = crc16(command, command_len);
    command[command_len] = crc & 0xFF;
    command[command_len + 1] = (crc >> 8) & 0xFF;
    command_len += 2;

    QString hexString="";
    for (int i = 0; i<command_len; ++i)
    {
        hexString += QString("%1 ").arg(static_cast<unsigned int>(command[i]), 2, 16, QChar('0'));
    }
    qDebug()<<hexString<<"---"<<command_len;

    //emit send_data_sig(App::UdpServerIP,App::UdpServerPort,hexString);
    udpSocket->writeDatagram((const char*)command,command_len, QHostAddress(App::UdpServerIP), App::UdpServerPort);

    QString str = QString("[%1:%2] %3").arg(App::UdpServerIP).arg(App::UdpServerPort).arg(hexString);
    append(0, str);
}

void frmUdpServer::on_pushButton_clicked()
{

    if(ui->pushButton->text()=="启动读取")
    {
        ui->pushButton->setText("关闭读取");
        unsigned char start_command[6] = { 0x01, 0x0A, 0x55, 0x55 };
        send_command( start_command, 4);
//        timer1->start(1000);
    }
    else
    {
        ui->pushButton->setText("启动读取");
//        timer1->stop();
    }

}

void frmUdpServer::on_pushButton_2_clicked()
{
    emit udp_close();
}
