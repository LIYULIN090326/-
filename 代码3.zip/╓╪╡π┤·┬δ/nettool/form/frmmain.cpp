﻿#include "frmmain.h"
#include "ui_frmmain.h"
#include "my_widget_form.h"
frmMain::frmMain(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::frmMain)
{
    ui->setupUi(this);
    ui->tabWidget->setCurrentIndex(0);


   connect(ui->tabUdpServer,SIGNAL(udp_close()),this,SLOT(udp_close()));
   connect(ui->tabUdpServer,SIGNAL(listen_sig(bool)),this,SIGNAL(listen_sig(bool)));
   //connect(ui->tabUdpServer,&frmUdpServer::send_data_sig,this,&frmMain::send_data_sig);
}

frmMain::~frmMain()
{
    delete ui;
}

void frmMain::udp_close()
{
    frmMain_hide();
    this->hide();

}

void frmMain::get_data(QString data)
{
    ui->tabUdpServer->get_esp8266_data(data);
}

void frmMain::parse_wavelength_data(QByteArray data)
{
    ui->tabUdpServer->parse_wavelength_data(data);
}

void frmMain::parse_intensity_data(QByteArray data)
{
    ui->tabUdpServer->parse_intensity_data(data);
}
