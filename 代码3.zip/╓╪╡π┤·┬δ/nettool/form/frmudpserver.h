﻿#ifndef FRMUDPSERVER_H
#define FRMUDPSERVER_H

#include <QWidget>
#include <QtNetwork>
#include <QTimer>
#include <QChart>
#include <QLineSeries>
#include <QValueAxis>
#include <QProcess>
#include <QtCharts>
#include <QSplineSeries>
#include "qmqtt_client.h"
#include "publisher.h"
#include "subscriber.h"
#include "alarmdialog.h"
namespace Ui {
class frmUdpServer;
}

class frmUdpServer : public QWidget
{
    Q_OBJECT

public:
    explicit frmUdpServer(QWidget *parent = 0);
    ~frmUdpServer();

private:
    Ui::frmUdpServer *ui;    

    QUdpSocket *udpSocket;
    QTimer *timer;
    QTimer *timer1;



    QChart *chart_w;
    QSplineSeries *series_w;
//    QSplineSeries *series_w_2;
    QChartView *chartview_w;
    QList<QPointF> pointList_w;
    QList<QPointF> pointList_w_2;

    QPointF pointw1;
    QPointF pointw2;

    double w_maxy=1536.58;
    double w_miny=1536.10;


    QChart *chart_i;
    QSplineSeries *series_i;
//    QSplineSeries *series_i_2;
    QChartView *chartview_i;
    QList<QPointF> pointList_i;
//    QList<QPointF> pointList_i_2;
    QPointF pointi1;
    QPointF pointi2;

    double i_maxy=0;
    double i_miny=10000;

    double waterLevel=0;
    double humidity=0;
    double temperature=0;
    double smoke=0;
    double strain1=0;
    double strain2=0;

    //mqtt相关参数
//    Subscriber *subscriber;

//    Publisher *publisher;



//报警阈值
    double waterLevel_alarm=30;//水位
    double humidity_alarm=100;//湿度
    double temperature_alarm=40;//温度
    double smoke_alarm=16;//烟雾
    double strain_alarm=0.1;//应变
    bool dialogshow;

    bool strain1dialogflag=false;
    bool strain2dialogflag=false;

public slots:
    void initForm();
    void initConfig();
    void saveConfig();
    void init_wavelength_widget();

    void init_intensity_widget();




    void update_myWidget(double,double,double,double,double,double);
    void update_myAlarmWidget(double,double,double,double,double,double);

    void append(int type, const QString &data, bool clear = false);

    void readData();
    void sendData(const QString &ip, int port, const QString &data);
    uint16_t crc16(const unsigned char* buf, int len);
    void send_command(unsigned char* command, size_t command_len);
    void deal_data(QByteArray data);
    void parse_wavelength_data(QByteArray data);
    void parse_intensity_data(QByteArray data);

    void update_W_Line();
    void update_I_Line();
    void getMaxMinY(const QList<QPointF> &pointList1,double &maxY,double &minY);
public slots:
    void get_esp8266_data(QString);
private slots:
    void on_btnListen_clicked();
    void on_btnSave_clicked();
    void on_btnClear_clicked();
    void on_btnSend_clicked();
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();

signals:
    void udp_close();
    //void send_data_sig(const QString &ip, int port, const QString &data);
    void listen_sig(bool);
};

#endif // FRMUDPSERVER_H
