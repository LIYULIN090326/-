#ifndef ALARMDIALOG_H
#define ALARMDIALOG_H

#include <QDialog>

namespace Ui {
class AlarmDialog;
}

class AlarmDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AlarmDialog(const QString &title, const QString &body,const QString &message, QWidget *parent = nullptr);
    ~AlarmDialog();

private slots:
    void on_close_clicked();

signals:
    void closeAlarm();

private:
    Ui::AlarmDialog *ui;
};

#endif // ALARMDIALOG_H
